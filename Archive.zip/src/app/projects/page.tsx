import CTA from "@/components/CTA/CTA";
import styles from "./page.module.css";

export const metadata = {
  title: "Projects",
  description:
    "Project categories at ProjectKaro: College mini projects, final-year projects, portfolio projects, and IoT projects. Pricing and timelines shared after abstract review.",
};

const CATEGORIES = [
  {
    title: "Mini Projects",
    description: "Short-term, focused projects suitable for semester or lab requirements. Ideal for building foundational skills.",
  },
  {
    title: "Final-Year Projects",
    description: "End-to-end support for your final-year or capstone project. From problem statement to documentation and delivery.",
  },
  {
    title: "Portfolio Projects",
    description: "Projects designed to showcase your skills and strengthen your resume for placements and internships.",
  },
  {
    title: "IoT Projects",
    description: "Hardware and software integration for Internet of Things applications. Sensors, connectivity, and real-world deployment.",
  },
];

export default function ProjectsPage() {
  return (
    <>
      <section className="section" aria-labelledby="projects-heading">
        <div className="container">
          <h1 id="projects-heading" className={styles.title}>
            Project Categories
          </h1>
          <p className={styles.intro}>
            We support a range of project types tailored to academic and career goals. Each category is designed to help you complete a real-world project with guided execution and academic documentation support.
          </p>

          <ul className={styles.categoryList} role="list">
            {CATEGORIES.map((cat) => (
              <li key={cat.title} className={styles.categoryCard}>
                <h2 className={styles.categoryTitle}>{cat.title}</h2>
                <p className={styles.categoryDesc}>{cat.description}</p>
              </li>
            ))}
          </ul>

          <div className={styles.note} role="note">
            <p>
              <strong>Pricing and timelines are shared after abstract review.</strong> Submit your project abstract via the Start a Project page, and our team will review scope and feasibility before sharing a tailored proposal.
            </p>
          </div>
        </div>
      </section>

      <CTA />
    </>
  );
}
