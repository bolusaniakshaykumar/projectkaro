import CTA from "@/components/CTA/CTA";
import styles from "./page.module.css";

export const metadata = {
  title: "How It Works",
  description:
    "How ProjectKaro works: Submit your project abstract, get scope and feasibility review, receive pricing and timeline via email, then guided execution to completion.",
};

const STEPS = [
  {
    number: 1,
    title: "Submit project abstract",
    description: "Fill out the Start a Project form with your details and upload your project abstract (PDF or DOC, max 2 MB). Include project title, description, and any requirements.",
  },
  {
    number: 2,
    title: "Team reviews scope and feasibility",
    description: "Our team reviews your abstract to understand scope, feasibility, and alignment with your goals. We may reach out with clarifying questions if needed.",
  },
  {
    number: 3,
    title: "Pricing & timeline shared via email",
    description: "Within 24–48 hours, we send you a tailored proposal with pricing and timeline. No upfront pricing—everything is based on your specific project.",
  },
  {
    number: 4,
    title: "Guided project execution and completion",
    description: "Once you confirm, we guide you through execution with clear milestones, documentation support, and completion deliverables.",
  },
];

export default function HowItWorksPage() {
  return (
    <>
      <section className="section" aria-labelledby="how-heading">
        <div className="container">
          <h1 id="how-heading" className={styles.title}>
            How It Works
          </h1>
          <p className={styles.intro}>
            Our process is designed to be clear and academic-focused. From abstract submission to completion, you stay informed at every step.
          </p>

          <ol className={styles.stepList} role="list">
            {STEPS.map((step) => (
              <li key={step.number} className={styles.step}>
                <span className={styles.stepNumber} aria-hidden="true">
                  {step.number}
                </span>
                <div className={styles.stepContent}>
                  <h2 className={styles.stepTitle}>{step.title}</h2>
                  <p className={styles.stepDesc}>{step.description}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <CTA />
    </>
  );
}
