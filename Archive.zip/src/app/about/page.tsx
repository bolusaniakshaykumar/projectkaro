import CTA from "@/components/CTA/CTA";
import styles from "./page.module.css";

export const metadata = {
  title: "About ProjectKaro",
  description:
    "ProjectKaro's mission: Help students complete real-world projects with an academic-first, student-centric approach. Focus on execution, not just ideas.",
};

export default function AboutPage() {
  return (
    <>
      <section className="section" aria-labelledby="about-heading">
        <div className="container">
          <div className={styles.hero}>
            <div className={styles.heroContent}>
              <p className={styles.heroLabel}>About ProjectKaro</p>
              <h1 id="about-heading" className={styles.heroTitle}>
                Empowering students to <span className={styles.heroAccent}>complete</span> their projects
              </h1>
              <p className={styles.heroSubtitle}>
                We bridge the gap between ideas and execution, helping engineering students and beginners turn concepts into finished, submission-ready projects.
              </p>
            </div>
            <div className={styles.heroVisual}>
              <div className={styles.statsGrid}>
                <div className={styles.stat}>
                  <div className={styles.statNumber}>500+</div>
                  <div className={styles.statLabel}>Projects Completed</div>
                </div>
                <div className={styles.stat}>
                  <div className={styles.statNumber}>98%</div>
                  <div className={styles.statLabel}>Success Rate</div>
                </div>
                <div className={styles.stat}>
                  <div className={styles.statNumber}>24/7</div>
                  <div className={styles.statLabel}>Support Available</div>
                </div>
              </div>
            </div>
          </div>

          <div className={styles.content}>
            <section className={styles.block} aria-labelledby="mission-heading">
              <div className={styles.blockHeader}>
                <div className={styles.blockIcon}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
                    <path d="M12 2v4M12 18v4M2 12h4M18 12h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <circle cx="12" cy="12" r="2" fill="currentColor"/>
                    <path d="M12 8v2M12 14v2M8 12h2M14 12h2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  </svg>
                </div>
                <h2 id="mission-heading" className={styles.blockTitle}>
                  Our Mission
                </h2>
              </div>
              <p>
                We help students complete real-world projects. Many students have ideas or requirements but struggle to execute—from choosing a problem statement to writing code, documentation, and delivering on time. ProjectKaro exists to bridge that gap with guided, structured support.
              </p>
            </section>

            <section className={styles.block} aria-labelledby="approach-heading">
              <div className={styles.blockHeader}>
                <div className={styles.blockIcon}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L8 6L12 10L16 6L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M12 10V14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M8 6H4M16 6H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <circle cx="12" cy="16" r="2" fill="currentColor" opacity="0.3"/>
                    <path d="M10 16H14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M12 18V20" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  </svg>
                </div>
                <h2 id="approach-heading" className={styles.blockTitle}>
                  Academic-First Approach
                </h2>
              </div>
              <p>
                We align with academic standards and requirements. Whether it&apos;s a college mini project, final-year project, or portfolio piece, we ensure the work is appropriate for submission, presentation, and evaluation. Documentation and deliverables are tailored to what institutions expect.
              </p>
            </section>

            <section className={styles.block} aria-labelledby="student-heading">
              <div className={styles.blockHeader}>
                <div className={styles.blockIcon}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M16 21V19C16 17.9391 15.5786 16.9217 14.8284 16.1716C14.0783 15.4214 13.0609 15 12 15H5C3.93913 15 2.92172 15.4214 2.17157 16.1716C1.42143 16.9217 1 17.9391 1 19V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M8.5 11C10.7091 11 12.5 9.20914 12.5 7C12.5 4.79086 10.7091 3 8.5 3C6.29086 3 4.5 4.79086 4.5 7C4.5 9.20914 6.29086 11 8.5 11Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M17 11L19 13M21 9L19 11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <circle cx="19" cy="11" r="3" stroke="currentColor" strokeWidth="2"/>
                  </svg>
                </div>
                <h2 id="student-heading" className={styles.blockTitle}>
                  Student-Centric Guidance
                </h2>
              </div>
              <p>
                Our support is designed around the student. We focus on clarity, timelines, and actionable steps so you can understand and own your project. The goal is not just to deliver a project for you, but to help you learn and complete it with confidence.
              </p>
            </section>

            <section className={styles.block} aria-labelledby="execution-heading">
              <div className={styles.blockHeader}>
                <div className={styles.blockIcon}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M12 12V22" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <circle cx="12" cy="7" r="1.5" fill="currentColor"/>
                  </svg>
                </div>
                <h2 id="execution-heading" className={styles.blockTitle}>
                  Focus on Execution, Not Just Ideas
                </h2>
              </div>
              <p>
                Ideas are easy; execution is hard. We help you move from abstract to working solution—with real-world problem statements, structured milestones, and completion-focused delivery. If you&apos;re ready to start or finish a project, we&apos;re here to help.
              </p>
            </section>
          </div>
        </div>
      </section>

      <CTA />
    </>
  );
}
