import dynamic from "next/dynamic";
import { FormSkeleton } from "@/components/Skeleton/Skeleton";
const StartProjectForm = dynamic(() => import("@/components/StartProjectForm/StartProjectForm"), {
  ssr: false,
  loading: () => <FormSkeleton />,
});
import styles from "./page.module.css";

export const metadata = {
  title: "Start a Project",
  description:
    "Submit your project abstract to ProjectKaro. Our team will review your abstract and respond within 24–48 hours with next steps.",
};

export default function StartAProjectPage() {
  return (
    <section className="section" aria-labelledby="start-heading">
      <div className="container">
        <h1 id="start-heading" className={styles.title}>
          Start a Project
        </h1>
        <p className={styles.intro}>
          Submit your project abstract below. Our team will review it and respond within 24–48 hours with next steps, including scope, feasibility, and a tailored proposal.
        </p>
        <StartProjectForm />
      </div>
    </section>
  );
}
