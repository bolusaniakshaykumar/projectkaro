import Link from "next/link";
import styles from "./Footer.module.css";

const FOOTER_LINKS = [
  { href: "/", label: "Home" },
  { href: "/projects", label: "Projects" },
  { href: "/how-it-works", label: "How It Works" },
  { href: "/about", label: "About" },
  { href: "/start-a-project", label: "Start a Project" },
];

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer} role="contentinfo">
      <div className="container">
        <div className={styles.inner}>
          <div className={styles.brand}>
            <Link href="/" className={styles.logo}>
              ProjectKaro
            </Link>
            <p className={styles.tagline}>
              Helping students build and complete real-world projects with guided, academic-focused support.
            </p>
          </div>
          <nav className={styles.nav} aria-label="Footer navigation">
            <ul className={styles.navList}>
              {FOOTER_LINKS.map(({ href, label }) => (
                <li key={href}>
                  <Link href={href} className={styles.navLink}>
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
          <div className={styles.contact}>
            <p className={styles.contactLabel}>Contact</p>
            <a href="mailto:contact@projectkaro.com" className={styles.email}>
              contact@projectkaro.com
            </a>
          </div>
        </div>
        <div className={styles.bottom}>
          <p className={styles.copyright}>
            &copy; {currentYear} ProjectKaro. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
