"use client";

import styles from "./Skeleton.module.css";

export function SkeletonLine({ className = "", style }: { className?: string; style?: React.CSSProperties }) {
  return <div className={`${styles.shimmer} ${styles.line} ${className}`} style={style} />;
}

export function SkeletonTitle({ className = "", style }: { className?: string; style?: React.CSSProperties }) {
  return <div className={`${styles.shimmer} ${styles.title} ${className}`} style={style} />;
}

export function SkeletonBlock({ height = 120, className = "" }: { height?: number; className?: string }) {
  return <div className={`${styles.shimmer} ${styles.block} ${className}`} style={{ height }} />;
}

export function FAQSkeleton() {
  return (
    <section aria-label="Loading FAQs">
      <div className="container">
        <SkeletonLine style={{ width: 72 }} />
        <SkeletonTitle style={{ width: 280 }} />
        <SkeletonLine style={{ width: 360 }} />
        <div className={styles.faqGrid} style={{ marginTop: 12 }}>
          {[...Array(6)].map((_, i) => (
            <div key={i} className={styles.faqItem}>
              <SkeletonLine style={{ width: "85%" }} />
              <SkeletonLine style={{ width: "60%" }} />
              <SkeletonLine style={{ width: "40%" }} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function FormSkeleton() {
  return (
    <div aria-label="Loading form" className={styles.formGrid}>
      <SkeletonLine style={{ width: 160 }} />
      <SkeletonLine style={{ width: "100%" }} />
      <SkeletonLine style={{ width: 180 }} />
      <SkeletonLine style={{ width: "100%" }} />
      <SkeletonLine style={{ width: 150 }} />
      <SkeletonLine style={{ width: "100%" }} />
      <SkeletonLine style={{ width: 220 }} />
      <SkeletonBlock height={100} />
      <SkeletonLine style={{ width: 280 }} />
      <SkeletonLine style={{ width: 200 }} />
      <SkeletonLine style={{ width: 140 }} />
      <SkeletonBlock height={60} />
    </div>
  );
}
