import Link from "next/link";
import styles from "./CTA.module.css";

interface CTAProps {
  title?: string;
  description?: string;
  showButton?: boolean;
}

export default function CTA({
  title = "Ready to start your project?",
  description = "Submit your project abstract and our team will review it. We'll get back to you within 24–48 hours with next steps.",
  showButton = true,
}: CTAProps) {
  return (
    <section className={`section ${styles.cta}`} aria-labelledby="cta-heading">
      <div className="container">
        <h2 id="cta-heading" className={styles.title}>
          {title}
        </h2>
        <p className={styles.description}>{description}</p>
        {showButton && (
          <Link href="/start-a-project" className="btn btn--primary">
            Start a Project
          </Link>
        )}
      </div>
    </section>
  );
}
